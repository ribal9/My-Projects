package printerQueue;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.*;
public class printerQueue {

	public static void main(String[] args) {
		String x = "y",username,password;
		int c = 0,d = 0,e = 0,f=0,g = 1,h = 1,i = 1,j = 1;
		Queue<String> queue = new LinkedList<String>();
		Scanner scanner = new Scanner(System.in);
		
		while (x.equals("y")) {
		
		System.out.println("Would you like to enter as guest(y/n)?");
		String a = scanner.nextLine();
		
		if (a.equals("y")) {
			f++;
			System.out.println("Guest has been entered...");

		}
		else if (a.equals("n")) {
			System.out.println("Enter User Name: ");
			username = scanner.nextLine();
			System.out.println("Enter Password: ");
			password = scanner.nextLine();
			if(username.equals("Wael")&& password.equals("pass1")){
				c++;
			}
			else if(username.equals("Ribal")&& password.equals("pass2")){
				d ++;
				
			}
			else if(username.equals("Amir")&& password.equals("pass3")) {
				e++;
				
			}
			else {
				System.out.println("Username or Password inncorrect ");
			}

		}
		System.out.println("Would you like to enter another user?(y/n)");
		x = scanner.nextLine();
		}
		
		
		
		while( c > 0) {
			queue.offer("Name : Wael - ID : 21930198 - Priority : 1 - Process :"+ g);
			g++;
			c--;
		}
		while (d > 0) {
			queue.offer("Name : Ribal - ID : 21930198 - Priority : 2 - Process :"+ h);
			h++;
			d--;
		}
		while (e > 0) {
			queue.offer("Name : Amir - ID : 21930198 - Priority : 3 - Process :"+ i);
			i++;
			e--;
		}
		
		while (f > 0) {
			queue.offer("Name : Guest - ID : guest-ID - Priority : 4 - Process :"+ j);
			j++;
			f--;
		}
		
		while(!queue.isEmpty()) {
		System.out.println(queue.poll());
		}
	}

}
